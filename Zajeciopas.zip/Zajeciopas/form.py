from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QTableWidget, QComboBox,
    QFormLayout, QGroupBox, QSizePolicy,
    QTabWidget, QWidget
)
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsProject, QgsMapLayerProxyModel


class message(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowTitle("Narzędzia FONDITEL")
        self.resize(1250, 750)

        main_layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        # TAB 1 – ZAJĘCIOPAS

        self.tab_zajeciopas = QWidget()
        self.tabs.addTab(self.tab_zajeciopas, "Zajęciopas")

        zaj_layout = QHBoxLayout(self.tab_zajeciopas)
        zaj_layout.setContentsMargins(15, 15, 15, 15)
        zaj_layout.setSpacing(20)

        # LEWY PANEL 

        left_panel = QVBoxLayout()

        group = QGroupBox("Warstwy wejściowe")
        group_layout = QFormLayout()
        group_layout.setLabelAlignment(Qt.AlignRight)
        group_layout.setSpacing(10)
        group.setLayout(group_layout)
        group.setMinimumWidth(480)
        group.setMaximumWidth(550)

        # Działki
        self.cmbDzialki = QgsMapLayerComboBox()
        self.cmbDzialki.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.cmbDzialki.setProject(QgsProject.instance())
        group_layout.addRow("Działki:", self.cmbDzialki)

        # Kable
        self.cmbKable = QgsMapLayerComboBox()
        self.cmbKable.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.cmbKable.setProject(QgsProject.instance())
        group_layout.addRow("Kable:", self.cmbKable)

        # Kanalizacja istniejąca
        self.cmbKanalizacja = QgsMapLayerComboBox()
        self.cmbKanalizacja.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.cmbKanalizacja.setProject(QgsProject.instance())
        group_layout.addRow("Kanalizacja istniejąca:", self.cmbKanalizacja)

        # Kanalizacja projektowana
        self.cmbKanalizacjaProj = QgsMapLayerComboBox()
        self.cmbKanalizacjaProj.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.cmbKanalizacjaProj.setProject(QgsProject.instance())
        group_layout.addRow("Kanalizacja projektowana:", self.cmbKanalizacjaProj)

        left_panel.addWidget(group)

        # Przycisk
        self.btnUruchom = QPushButton("Przytnij")
        self.btnUruchom.setMinimumHeight(38)
        left_panel.addWidget(self.btnUruchom)

        left_panel.addStretch()

        left_panel.addWidget(QLabel("Pokaż tabelę:"))
        self.cmbTabela = QComboBox()
        self.cmbTabela.addItems([
            "Tabela kabli",
            "Tabela kanalizacji projektowanej"
        ])
        left_panel.addWidget(self.cmbTabela)

        # PRAWA STRONA 

        right_panel = QVBoxLayout()

        right_panel.addWidget(QLabel("Wyniki:"))

        self.tblWyniki = QTableWidget()
        self.tblWyniki.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        right_panel.addWidget(self.tblWyniki)

        self.tblKanalizacja = QTableWidget()
        self.tblKanalizacja.hide()
        right_panel.addWidget(self.tblKanalizacja)

        bottom_buttons = QHBoxLayout()
        bottom_buttons.addStretch()

        self.btnExcel = QPushButton("Eksport do Excel")
        bottom_buttons.addWidget(self.btnExcel)

        self.btnAgreguj = QPushButton("Agreguj")
        bottom_buttons.addWidget(self.btnAgreguj)

        right_panel.addLayout(bottom_buttons)

        zaj_layout.addLayout(left_panel)
        zaj_layout.addLayout(right_panel)

        zaj_layout.setStretch(0, 3)
        zaj_layout.setStretch(1, 4)

        # TAB 2 – TAURON

        self.tab_tauron = QWidget()
        self.tabs.addTab(self.tab_tauron, "Tauron")

        # Pusty layout 
        tauron_layout = QVBoxLayout(self.tab_tauron)
        tauron_layout.addStretch()